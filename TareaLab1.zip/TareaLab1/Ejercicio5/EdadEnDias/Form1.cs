﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EdadEnDias
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            // evento MouseClick
            txtEdad.MouseClick += new MouseEventHandler(txtEdad_MouseClick);
        }

        private void btnConvertir_Click(object sender, EventArgs e)
        {
            // Validar que el TextBox no esté vacío
            if (string.IsNullOrWhiteSpace(txtEdad.Text))
            {
                MessageBox.Show("Por favor, ingrese una edad.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Validar que el valor ingresado sea un número entero, positivo
            if (!int.TryParse(txtEdad.Text, out int edad) || edad < 0)
            {
                MessageBox.Show("Por favor, ingrese un número válido mayor o igual a cero.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Calcular la edad en días
            int edadEnDias = edad * 365;

            // Mostrar el resultado
            lblResultado.Text = $"Tu edad en días es: {edadEnDias}";
        }

        private void txtEdad_MouseClick(object sender, MouseEventArgs e)
        {
            //evento mouseClick
            // Limpia el texto del TextBox al hacer clic sobre el
            txtEdad.Clear();
        }
    }
}