﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestringirLetras
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.KeyPreview = true; // Permite que el formulario capture eventos de teclado
            this.KeyDown += new KeyEventHandler(Form1_KeyDown);
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.I || e.KeyCode == Keys.J || e.KeyCode == Keys.K || e.KeyCode == Keys.L)
            {
                // se cambia el texto del Label
                lblMensaje.Text = "Esta tecla está prohibida."; 
                e.SuppressKeyPress = true; 
            }
            else
            {
                // Limpia el mensaje si se presiona otra tecla
                lblMensaje.Text = ""; 
            }
        }
    }
}