﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Resources.ResXFileRef;

namespace convertidordeMillas_Km
{
    public partial class Form1 : Form
    {
        // Constructor
        public Form1()
        {
            InitializeComponent();
        }

        // Evento que se dispara cuando se hace clic en el botón para convertir a millas.
        private void btnConvertirAMillas_Click(object sender, EventArgs e)
        {
            try
            {
                double kilometros = double.Parse(txtKilometros.Text);

                // Llamamos al método para convertir kilómetros a millas.
                double millas = Conversor.KilometrosAMillas(kilometros);

                // Mostramos el resultado en el Label correspondiente.
                lblResultadoMillas.Text = $"{kilometros} kilómetros son {millas:F2} millas.";
            }
            catch (FormatException)
            {
                // Si el usuario ingresa un texto no numérico
                // mostramos un mensaje de error.
                MessageBox.Show("Ingrese un valor numérico válido para kilómetros.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // 
        private void btnConvertirAKilometros_Click(object sender, EventArgs e)
        {
            try
            {
                // 
                double millas = double.Parse(txtMillas.Text);

                // 
                double kilometros = Conversor.MillasAKilometros(millas);

                // 
                lblResultadoKilometros.Text = $"{millas} millas son {kilometros:F2} kilómetros.";
            }
            catch (FormatException)
            {
                // 
                // 
                MessageBox.Show("Ingrese un valor numérico válido para millas.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}