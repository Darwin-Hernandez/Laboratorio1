﻿// Nombre Clase
public class Conversor
{
    // Constante que define cuántos kilómetros hay en una milla.
    private const double KilometrosPorMilla = 1.60934;

    // Constante que define cuántas millas hay en un kilómetro.
    private const double MillasPorKilometro = 0.621371;

    // Método que convierte millas a kilómetros.
    public static double MillasAKilometros(double millas)
    {
        return millas * KilometrosPorMilla;
    }

    // Método que convierte kilómetros a millas.
    public static double KilometrosAMillas(double kilometros)
    {
        return kilometros * MillasPorKilometro;
    }
}
