﻿using System;
using System.Windows.Forms;
namespace convertidordeMillas_Km
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        private TextBox txtMillas;
        private TextBox txtKilometros;
        private Button btnConvertirAMillas;
        private Button btnConvertirAKilometros;
        private Label lblResultadoMillas;
        private Label lblResultadoKilometros;

        private void InitializeComponent()
        {
            this.txtMillas = new System.Windows.Forms.TextBox();
            this.txtKilometros = new System.Windows.Forms.TextBox();
            this.btnConvertirAMillas = new System.Windows.Forms.Button();
            this.btnConvertirAKilometros = new System.Windows.Forms.Button();
            this.lblResultadoMillas = new System.Windows.Forms.Label();
            this.lblResultadoKilometros = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtMillas
            // 
            this.txtMillas.AccessibleDescription = "";
            this.txtMillas.AccessibleName = "";
            this.txtMillas.Location = new System.Drawing.Point(12, 12);
            this.txtMillas.Name = "txtMillas";
            this.txtMillas.Size = new System.Drawing.Size(100, 20);
            this.txtMillas.TabIndex = 0;
            // 
            // txtKilometros
            // 
            this.txtKilometros.Location = new System.Drawing.Point(12, 38);
            this.txtKilometros.Name = "txtKilometros";
            this.txtKilometros.Size = new System.Drawing.Size(100, 20);
            this.txtKilometros.TabIndex = 1;
            // 
            // btnConvertirAMillas
            // 
            this.btnConvertirAMillas.Location = new System.Drawing.Point(118, 12);
            this.btnConvertirAMillas.Name = "btnConvertirAMillas";
            this.btnConvertirAMillas.Size = new System.Drawing.Size(75, 23);
            this.btnConvertirAMillas.TabIndex = 2;
            this.btnConvertirAMillas.Text = "A Millas";
            this.btnConvertirAMillas.UseVisualStyleBackColor = true;
            this.btnConvertirAMillas.Click += new System.EventHandler(this.btnConvertirAMillas_Click);
            // 
            // btnConvertirAKilometros
            // 
            this.btnConvertirAKilometros.Location = new System.Drawing.Point(118, 38);
            this.btnConvertirAKilometros.Name = "btnConvertirAKilometros";
            this.btnConvertirAKilometros.Size = new System.Drawing.Size(75, 23);
            this.btnConvertirAKilometros.TabIndex = 3;
            this.btnConvertirAKilometros.Text = "A Kilómetros";
            this.btnConvertirAKilometros.UseVisualStyleBackColor = true;
            this.btnConvertirAKilometros.Click += new System.EventHandler(this.btnConvertirAKilometros_Click);
            // 
            // lblResultadoMillas
            // 
            this.lblResultadoMillas.AutoSize = true;
            this.lblResultadoMillas.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblResultadoMillas.Location = new System.Drawing.Point(12, 77);
            this.lblResultadoMillas.Name = "lblResultadoMillas";
            this.lblResultadoMillas.Size = new System.Drawing.Size(0, 13);
            this.lblResultadoMillas.TabIndex = 4;
            // 
            // lblResultadoKilometros
            // 
            this.lblResultadoKilometros.AutoSize = true;
            this.lblResultadoKilometros.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblResultadoKilometros.Location = new System.Drawing.Point(12, 90);
            this.lblResultadoKilometros.Name = "lblResultadoKilometros";
            this.lblResultadoKilometros.Size = new System.Drawing.Size(0, 13);
            this.lblResultadoKilometros.TabIndex = 5;
            // 
            // Form1
            // 
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.lblResultadoKilometros);
            this.Controls.Add(this.lblResultadoMillas);
            this.Controls.Add(this.btnConvertirAKilometros);
            this.Controls.Add(this.btnConvertirAMillas);
            this.Controls.Add(this.txtKilometros);
            this.Controls.Add(this.txtMillas);
            this.Name = "Form1";
            this.Text = "Conversor";
            this.ResumeLayout(false);
            this.PerformLayout();

        }
    }
}


            
