﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PrimeraLetraMayuscula
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCapitalizar_Click(object sender, EventArgs e)
        {
            string input = txtInput.Text;
            string capitalizado = CapitalizarPalabras(input);
            lblResultado.Text = capitalizado;
        }

        private string CapitalizarPalabras(string texto)
        {
            if (string.IsNullOrEmpty(texto))
            {
                return string.Empty;
            }

            // Divide el texto en palabras
            string[] palabras = texto.Split(' ');

            // Recorre las palabras y cambia a mayus la primera letra de cada una
            for (int i = 0; i < palabras.Length; i++)
            {
                if (!string.IsNullOrEmpty(palabras[i]))
                {
                    palabras[i] = char.ToUpper(palabras[i][0]) + palabras[i].Substring(1).ToLower();
                }
            }

            // 
            return string.Join(" ", palabras);
        }

        private void txtInput_MouseClick(object sender, MouseEventArgs e)
        {
            // Evento de mouse
            MessageBox.Show("Haz clic en el cuadro de texto.");
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtInput_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
