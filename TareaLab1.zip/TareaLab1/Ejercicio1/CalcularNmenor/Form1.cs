﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalcularNmenor
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            // Asocia los eventos de mouse al botón
            btnCalcular.MouseEnter += btnCalcular_MouseEnter;
            btnCalcular.MouseLeave += btnCalcular_MouseLeave;
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            try
            {
                // Validar que los TextBox no estén vacíos
                if (string.IsNullOrWhiteSpace(txtNumero1.Text) ||
                    string.IsNullOrWhiteSpace(txtNumero2.Text) ||
                    string.IsNullOrWhiteSpace(txtNumero3.Text))
                {
                    throw new Exception("Todos los campos deben estar llenos.");
                }

                // Convertir los textos a números
                double numero1 = Convert.ToDouble(txtNumero1.Text);
                double numero2 = Convert.ToDouble(txtNumero2.Text);
                double numero3 = Convert.ToDouble(txtNumero3.Text);

                // Determinar el menor
                double menor = Math.Min(Math.Min(numero1, numero2), numero3);

                // Mostrar el resultado
                lblResultado.Text = $"El número menor es: {menor}";
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor, ingrese valores numéricos válidos.", "Error de formato", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        //Eventos de Mouse
        private void btnCalcular_MouseEnter(object sender, EventArgs e)
        {
            btnCalcular.BackColor = Color.DarkMagenta;
        }

        private void btnCalcular_MouseLeave(object sender, EventArgs e)
        {
            btnCalcular.BackColor = SystemColors.Control;
        }
    }
}
